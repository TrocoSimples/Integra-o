﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Troco.WebApi.Integracao.Domain;

namespace Troco.WebApi.Integracao
{
    public class LoginBase
    {
        public string ObterAutorizacao()
        {
            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri(Urls.Server);

                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    var name = "teste@trocosimples.com.br";
                    var pw = "123456";

                    Task<HttpResponseMessage> task = client.PostAsync("token", new StringContent("grant_type=password&username=" + name + "&password=" + pw));

                    task.Wait();
                    var response = task.Result;

                    response.EnsureSuccessStatusCode();
                    var ContenTask = response.Content.ReadAsAsync<TokenObject>();

                    ContenTask.Wait();
                    var token = ContenTask.Result;


                    ///Todas as demais requisições devem conter esta linha de autorização no header
                    var Authorization = token.token_type + " " + token.access_token;

                    return Authorization;

                }
                catch (HttpRequestException e)
                {
                    // Handle exception.
                    return null;
                }
            }
        }
    }
}
