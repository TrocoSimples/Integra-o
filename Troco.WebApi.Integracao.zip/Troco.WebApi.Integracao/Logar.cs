﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Troco.WebApi.Integracao.Domain;

namespace Troco.WebApi.Integracao
{
    [TestClass]
    public class Logar
    {
        /// <summary>
        /// Demonstra como realizar o login no sistema
        /// </summary>
        [TestMethod]
        public void RealizarLogin()
        {
            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri("http://localhost:60989/api/");

                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    var name = "teste@trocosimples.com.br";
                    var pw = "123456";

                    Task<HttpResponseMessage> task = client.PostAsync("token", new StringContent("grant_type=password&username=" + name + "&password=" + pw));

                    task.Wait();
                    var response = task.Result;

                    response.EnsureSuccessStatusCode();
                    var ContenTask = response.Content.ReadAsAsync<TokenObject>();

                    ContenTask.Wait();
                    var token = ContenTask.Result;


                    ///Todas as demais requisições devem conter esta linha de autorização no header
                    var Authorization = token.token_type + " " + token.access_token;

                }
                catch (HttpRequestException e)
                {
                    // Handle exception.
                }
            }
        }
    }
}
