﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Troco.WebApi.Integracao.Domain;
using System.Collections.Generic;

namespace Troco.WebApi.Integracao
{
    [TestClass]
    public class Extrato : LoginBase
    {
        /// <summary>
        /// Demonstra como obter o extrato da empresa informada
        /// </summary>
        [TestMethod]
        public void ObterExtrato()

        {
            var Authorization = base.ObterAutorizacao();

            using (var client = new HttpClient())
            {
                var enterpriseId = 3;

                try
                {
                    client.BaseAddress = new Uri("http://localhost:60989/api/");

                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var auth = Authorization.Split(' ');
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(auth[0], auth[1]);

                    Task<HttpResponseMessage> task = client.GetAsync("enterprise/"+enterpriseId+ "/account/history");

                    task.Wait();
                    var response = task.Result;

                    response.EnsureSuccessStatusCode();

                    
                    var balanceJson = response.Content.ReadAsStringAsync();
                    balanceJson.Wait();

                    JavaScriptSerializer JSserializer = new JavaScriptSerializer();

                    //Saldo após a operação
                    var history = JSserializer.Deserialize<List<HistoryObject>>(balanceJson.Result);

                }
                catch (HttpRequestException e)
                {
                    // Handle exception.
                }
            }
        }
    }
}
