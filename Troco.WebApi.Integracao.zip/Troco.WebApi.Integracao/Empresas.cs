﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Troco.WebApi.Integracao.Domain;
using System.Collections.Generic;

namespace Troco.WebApi.Integracao
{
    [TestClass]
    public class Empresas : LoginBase
    {
        /// <summary>
        /// Demontra como obter as empresas vinculadas ao usuário logado.
        /// Dentre estas estarão as empresas de propriendade do proprio usuário, assim como as viculadas a este por outros usuário
        /// </summary>
        [TestMethod]
        public void ObterEmpresasVinculadasAoUsuario()

        {
            var Authorization = base.ObterAutorizacao();

            using (var client = new HttpClient())
            {
                try
                {
                    client.BaseAddress = new Uri("http://homolog-trocosimples-com-br.umbler.net/api/");

                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var auth = Authorization.Split(' ');
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(auth[0], auth[1]);

                    Task<HttpResponseMessage> task = client.GetAsync("user/enterprises/");

                    task.Wait();
                    var response = task.Result;

                    response.EnsureSuccessStatusCode();

                    
                    var balanceJson = response.Content.ReadAsStringAsync();
                    balanceJson.Wait();

                    JavaScriptSerializer JSserializer = new JavaScriptSerializer();

                    //Saldo após a operação
                    var enterprises = JSserializer.Deserialize<List<EnterpriseObject>>(balanceJson.Result);

                }
                catch (HttpRequestException e)
                {
                    // Handle exception.
                }
            }
        }
    }
}
