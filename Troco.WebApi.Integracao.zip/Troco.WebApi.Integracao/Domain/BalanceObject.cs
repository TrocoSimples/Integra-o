﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Troco.WebApi.Integracao.Domain
{
    public class BalanceObject
    {
        /// <summary>
        /// Saldo atual
        /// </summary>
        public decimal value { get; set; }
    }
}
