﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Troco.WebApi.Integracao.Domain
{
    public class TokenObject
    {
        /// <summary>
        /// Token para acesso as funcinalidades do troco simples
        /// </summary>
        public string access_token { get; set; }

        /// <summary>
        /// Tipo de token utilizado
        /// </summary>
        public string token_type { get; set; }
    }
}
