﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Troco.WebApi.Integracao.Domain;
using System.Web.Script.Serialization;

namespace Troco.WebApi.Integracao
{
    [TestClass]
    public class EntregarTroco : LoginBase
    {
        /// <summary>
        /// Demonstra como realizar a entrega de troco utilizando uma empresa especifica
        /// </summary>
        [TestMethod]
        public void EntregarDeTroco()
        {
            var Authorization = base.ObterAutorizacao();

            using (var client = new HttpClient())
            {
                var enterpriseId = 3;

                try
                {
                    client.BaseAddress = new Uri("http://localhost:60989/api/");

                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var auth = Authorization.Split(' ');
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(auth[0], auth[1]);

                    var content = new
                    {
                        cpfDestination = 09298031599,
                        amount = 0.01,
                        //Este valor não é validado, deve ser utilizado como controle pelo ERP para diferenciar seus usuários
                        enterpriseUser = 12
                    };

                    Task<HttpResponseMessage> task = client.PostAsJsonAsync("enterprise/"+enterpriseId+"/delivery", content);

                    task.Wait();
                    var response = task.Result;

                    response.EnsureSuccessStatusCode();

                }
                catch (HttpRequestException e)
                {
                    // Handle exception.
                }
            }
        }
    }
}
