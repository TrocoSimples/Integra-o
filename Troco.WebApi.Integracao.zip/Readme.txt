﻿Disponível no site:
https://github.com/TrocoSimples/Integracao

Url Integração
http://homolog-trocosimples-com-br.umbler.net/api/

Usuário Teste
teste@trocosimples.com.br

Senha
123456

CPF usuário teste
72539019404

CNPJ Empresa Teste
23513265000199