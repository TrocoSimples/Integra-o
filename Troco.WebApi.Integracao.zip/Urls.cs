﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Troco.WebApi.Integracao
{
    public class Urls
    {
        public static string Server = "http://homolog-trocosimples-com-br.umbler.net/api/";
        //public static string Server = "http://localhost:60989/api/";
    }
}
