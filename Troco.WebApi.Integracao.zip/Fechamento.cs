﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Troco.WebApi.Integracao.Domain;
using System.Web.Script.Serialization;
using System.IO;

namespace Troco.WebApi.Integracao
{
    [TestClass]
    public class Fechamento : LoginBase
    {
        /// <summary>
        /// Demonstra como solicitar um pagamento
        /// </summary>
        [TestMethod]
        public void ObterFechamento()
        {
            var Authorization = base.ObterAutorizacao();

            using (var client = new HttpClient())
            {
                var enterpriseId = 7;

                try
                {
                    client.BaseAddress = new Uri(Urls.Server);

                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var auth = Authorization.Split(' ');
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(auth[0], auth[1]);

                    var content = new
                    {
                        //daily | monthly | weekly
                        type = "monthly",
                        StartDate = "2016-09-05T00:00:00",
                        //Este valor não é validado, deve ser utilizado como controle pelo ERP para diferenciar seus usuários
                        //Caso seja informado nulo, será retornado de todos os usuários
                        enterpriseUser = 7
                    };

                    Task<HttpResponseMessage> task = client.PostAsJsonAsync("enterprise/"+enterpriseId+ "/account/history/csv", content);

                    task.Wait();
                    var response = task.Result;

                    response.EnsureSuccessStatusCode();

                    var csv = response.Content.ReadAsByteArrayAsync();
                    csv.Wait();

                    File.WriteAllBytes(@"c:\Temp\fechamento.csv", csv.Result);

                }
                catch (HttpRequestException e)
                {
                    // Handle exception.
                }
            }
        }
    }
}
