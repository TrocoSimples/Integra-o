﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Troco.WebApi.Integracao.Domain;

namespace Troco.WebApi.Integracao
{
    [TestClass]
    public class Saldo : LoginBase
    {
        /// <summary>
        /// Demonstra como obter o saldo da empresa
        /// </summary>
        [TestMethod]
        public void ObterSaldo()

        {
            var Authorization = base.ObterAutorizacao();

            using (var client = new HttpClient())
            {
                var enterpriseId = 7;

                try
                {
                    client.BaseAddress = new Uri(Urls.Server);

                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var auth = Authorization.Split(' ');
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(auth[0], auth[1]);

                    Task<HttpResponseMessage> task = client.GetAsync("enterprise/"+enterpriseId+"/account/balance");

                    task.Wait();
                    var response = task.Result;

                    response.EnsureSuccessStatusCode();

                    
                    var balanceJson = response.Content.ReadAsStringAsync();
                    balanceJson.Wait();

                    JavaScriptSerializer JSserializer = new JavaScriptSerializer();

                    //Saldo após a operação
                    var balance = JSserializer.Deserialize<BalanceObject>(balanceJson.Result);

                }
                catch (HttpRequestException e)
                {
                    // Handle exception.
                }
            }
        }
    }
}
