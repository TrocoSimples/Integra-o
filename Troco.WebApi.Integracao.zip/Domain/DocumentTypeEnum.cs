﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Troco.WebApi.Integracao.Domain
{
    public enum DocumentTypeEnum
    {
        CNPJ = 0,
        CPF = 1,
        Matricula = 2
    }
}
