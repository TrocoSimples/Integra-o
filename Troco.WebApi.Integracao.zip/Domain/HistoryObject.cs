﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Troco.WebApi.Integracao.Domain
{
    public class HistoryObject
    {
        /// <summary>
        /// CPF do recebedor
        /// </summary>
        public long? cpf { get; set; }

        /// <summary>
        /// Documento da empresa
        /// </summary>
        public long? documentNumber { get; set; }

        /// <summary>
        /// Tipo do documento da empresa
        /// CNPJ/CPF/Matricula
        /// </summary>
        public DocumentTypeEnum documentType { get; set; }

        /// <summary>
        /// Usuário que recebeu a movimentação
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// Data da movimentação
        /// </summary>
        public string date { get; set; }

        /// <summary>
        /// Valor movimentado sem sinal
        /// </summary>
        public decimal absoluteValue { get; set; }

        /// <summary>
        /// + Indica que a empresa recebeu o valor
        /// - Indica que a empresa pagou o valor
        /// </summary>
        public string signal { get; set; }

        /// <summary>
        /// EntregaTroco = 0
        /// Pagamento = 1
        /// Transferencia = 2
        /// Credito = 3
        /// </summary>
        public string movementType { get; set; }

        /// <summary>
        /// Usuário que realizou a operação
        /// </summary>
        public string userName { get; set; }
    }
}
