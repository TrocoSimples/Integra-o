﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Troco.WebApi.Integracao.Domain
{
    public class EnterpriseObject
    {
        /// <summary>
        /// Identificador da empresa
        /// </summary>
        public int enterpriseId { get; set; }

        /// <summary>
        /// Nome da empresa
        /// </summary>
        public string enterpriseName { get; set; }

        /// <summary>
        /// Documento da empresa
        /// </summary>
        public long documentNumber { get; set; }

        /// <summary>
        /// Tipo do documento da empresa
        /// CNPJ/CPF/Matricula
        /// </summary>
        public DocumentTypeEnum documentType { get; set; }

        /// <summary>
        /// Saldo
        /// </summary>
        public decimal currentBalance { get; set; }

        /// <summary>
        /// Regra em relação ao usuário logado
        /// NaoDefinido = 0
        /// Administrador = 1
        /// Financeiro = 2
        /// </summary>
        public string currentUserRole { get; set; }
    }
}
